/// Credit merydwin@gmail.com
#pragma once

namespace BNet2 {

    /// Packets channel
    enum Channels
    {
        BATTLENET2_CHANNEL_NONE     = 0x00,
        BATTLENET2_CHANNEL_CREEP    = 0x01,
        BATTLENET2_CHANNEL_WOW      = 0x02,
    };

}